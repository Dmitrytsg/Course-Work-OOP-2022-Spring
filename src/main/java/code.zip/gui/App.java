package gui;

import java.awt.event.ActionListener;
import javax.persistence.*;
import cinemaProject.*;

import javax.swing.*;
import java.awt.*;
import java.util.concurrent.atomic.AtomicInteger;

public class App {
	public static void main(String args[]) throws Exception {

            new Interface();

        }

}
